package com.example.pubgping;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private final String[] names = {
        "Cloudflare — 1.1.1.1",
        "Google — 8.8.8.8",
        "Quad9 — 9.9.9.9"
    };

    private final String[] dns = {
        "one.one.one.one",
        "dns.google",
        "dns.quad9.net"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.dnsSpinner);
        TextView selected = findViewById(R.id.selectedDns);
        Button openSettings = findViewById(R.id.openSettings);

        spinner.setAdapter(new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_dropdown_item, names));

        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                selected.setText("نام Private DNS: " + dns[position]);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        openSettings.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_PRIVATE_DNS_SETTINGS);
            try {
                startActivity(intent);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            }
        });
    }
}
